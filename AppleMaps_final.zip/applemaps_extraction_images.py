import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from time import sleep
from datetime import datetime
from PIL import Image
import os
import numpy as np

starttime = datetime.now()
inputfile = 'testing1_latlng.xlsx'
outputfolder = 'D:\\Solutions\\Maps\\testing1\\'
result_df = []
outputfile = outputfolder + 'testing1_latlng_filtered.xlsx'
lat_long = pd.read_excel(inputfile)
lat = lat_long['Latitude'].values.tolist()
lon = lat_long['Longitude'].values.tolist()
for index, row in lat_long.iterrows():
    try:
        lat = round(float(row['Latitude']), 5)
        lon = round(float(row['Longitude']), 5)
        # lat = round(float(lat[i]), 5)
        # lon = round(float(lon[i]), 5)
        apple_image = outputfolder + f'({lat}_{lon})apple_image.png'
        google_image = outputfolder + f'({lat}_{lon})google_image.png'
        # sleep(5)
        print(apple_image)
        print(google_image)
        img = Image.open(apple_image)
        img = img.convert("RGB")
        co_ordinates = [(59, 13), (59, 19), (108,13), (108,19), (113, 13), (113, 19), (124,15)]
        flag = False
        for co_ordinate in co_ordinates:
            co_ordinate_tuple = img.getpixel(co_ordinate)
            if co_ordinate_tuple != (72, 69, 65):
                flag = True
                break

        print(flag)
        if flag == True:
            os.remove(apple_image)
            os.remove(google_image)
        else:
            temp = pd.DataFrame({'Latitude': lat, 'Longitude': lon}, index=[0])
            result_df.append(temp)
    except:
        continue
if len(result_df) > 0:
    result_df = pd.concat(result_df, ignore_index=True)
    result_df.to_excel(outputfile, index = False)
endtime = datetime.now()
diff = endtime - starttime
print(diff.seconds)